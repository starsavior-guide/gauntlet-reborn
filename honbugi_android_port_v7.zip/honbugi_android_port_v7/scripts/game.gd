extends Node2D

const MOVE_SPEED := 260.0
const DASH_SPEED := 610.0
const DODGE_SPEED := 480.0
const JUMP_VELOCITY := -510.0
const GRAVITY := 1450.0
const SAVE_PATH := "user://honbugi_v7_save.json"
const LEGACY_SAVE_PATH := "user://honbugi_v6_save.json"

var current_stage := "outside"
var stage_node: Node2D
var player: CharacterBody2D
var player_sprite: AnimatedSprite2D
var camera: Camera2D
var attack_area: Area2D
var facing := 1.0
var state := "normal"
var state_timer := 0.0
var invuln_timer := 0.0
var combo_step := 0
var combo_window := 0.0
var attack_hit_ids := {}
var player_hp := 100
var player_max_hp := 100
var credits := 100
var jump_count := 0
var portal_lock := 0.0

var checkpoint_stage := "outside"
var checkpoint_pos := Vector2(2002,453)
var collected := {}
var flags := {
    "turtle": false,
    "turtle_jump": false,
    "map": false,
    "candle": false,
    "ufo": false,
    "ps5": false,
    "head": false,
    "body": false,
    "hands": false,
    "feet": false,
    "boss_crab": false,
    "boss_harvester": false,
    "boss_chamber": false,
    "boss_black": false
}
var alcohol := 0

var stage_manifest := {}
var portals_root := {}
var entities_root := {}
var enemy_visuals := {}
var item_visuals := {}
var stage_meta := {}
var player_frames: SpriteFrames
var item_frames: SpriteFrames
var boss_frames: SpriteFrames
var harvester_frames: SpriteFrames
var chamber_frames: SpriteFrames
var black_frames: SpriteFrames
var boss_programs_v6 := {}
var pgmmv_program_root := {}
var boss_action_label: Label

var enemies: Array[CharacterBody2D] = []
var breakables: Array[CharacterBody2D] = []
var pickups: Array[Area2D] = []
var projectiles: Array[Node2D] = []
var save_points: Array[Vector2] = []
var boss: CharacterBody2D

var bgm: AudioStreamPlayer
var sfx: AudioStreamPlayer
var hp_bar: ProgressBar
var hp_label: Label
var credit_label: Label
var stage_label: Label
var ui_message: Label
var save_hint: Label
var boss_bar: ProgressBar
var boss_label: Label
var inventory_panel: Panel
var inventory_text: Label

func _ready() -> void:
    randomize()
    _setup_keyboard_input()
    stage_manifest = _read_json("res://data/stage_manifest_v5.json")
    portals_root = _read_json("res://data/portals_v5.json")
    entities_root = _read_json("res://data/entities_v5.json")
    enemy_visuals = _read_json("res://data/enemy_visuals_v4.json")
    item_visuals = _read_json("res://data/item_visuals_v4.json")
    player_frames = _load_frames("res://data/player_v3_animations.json")
    item_frames = _load_frames("res://data/item_v3_animations.json")
    boss_frames = _load_frames("res://data/boss_crab_animations.json")
    harvester_frames = _load_frames("res://data/boss_harvester_animations.json")
    chamber_frames = _load_frames("res://data/boss_chamber_animations.json")
    black_frames = _load_frames("res://data/boss_black_animations.json")
    pgmmv_program_root = _read_json("res://data/pgmmv_boss_programs_v6.json")
    boss_programs_v6 = pgmmv_program_root.get("bosses",{})
    bgm = AudioStreamPlayer.new(); add_child(bgm)
    sfx = AudioStreamPlayer.new(); add_child(sfx)
    _create_ui()
    _load_stage("outside", Vector2(2002,453))
    if FileAccess.file_exists(SAVE_PATH):
        _flash_message("V7 저장 데이터 감지 • LOAD/F9로 불러오기")
    elif FileAccess.file_exists(LEGACY_SAVE_PATH):
        _flash_message("V6 저장 감지 • LOAD/F9로 불러오면 V7로 이관")
    elif FileAccess.file_exists("user://honbugi_v5_save.json") or FileAccess.file_exists("user://honbugi_v4_save.json"):
        _flash_message("구버전 저장 감지 • V7은 V6 저장부터 자동 이관")

func _setup_keyboard_input() -> void:
    _bind_key("move_left", KEY_A); _bind_key("move_left", KEY_LEFT)
    _bind_key("move_right", KEY_D); _bind_key("move_right", KEY_RIGHT)
    _bind_key("jump", KEY_SPACE)
    _bind_key("attack", KEY_J)
    _bind_key("strong_attack", KEY_K)
    _bind_key("dash", KEY_L); _bind_key("dash", KEY_SHIFT)
    _bind_key("dodge", KEY_Q)
    _bind_key("interact", KEY_E)
    _bind_key("save_game", KEY_F5)
    _bind_key("load_game", KEY_F9)
    _bind_key("inventory", KEY_I)

func _bind_key(action: StringName, code: int) -> void:
    if not InputMap.has_action(action): InputMap.add_action(action)
    var ev := InputEventKey.new(); ev.physical_keycode = code
    InputMap.action_add_event(action, ev)

func _read_json(path: String):
    var f := FileAccess.open(path, FileAccess.READ)
    return JSON.parse_string(f.get_as_text()) if f else {}

func _load_frames(path: String) -> SpriteFrames:
    var parsed = _read_json(path)
    var sf := SpriteFrames.new(); sf.remove_animation("default")
    for name in parsed.keys():
        sf.add_animation(name)
        sf.set_animation_speed(name, 300.0)
        sf.set_animation_loop(name, bool(parsed[name].get("loop", false)))
        for fr in parsed[name].get("frames",[]):
            var tex = load("res://" + String(fr["file"]))
            sf.add_frame(name, tex, float(fr.get("duration300",5)))
    return sf

func _load_stage(which: String, spawn: Vector2) -> void:
    if not stage_manifest.has(which):
        _flash_message("미구현 스테이지: " + which)
        return
    current_stage = which
    portal_lock = 0.75
    _clear_dynamic_entities()
    if stage_node and is_instance_valid(stage_node): stage_node.queue_free()
    stage_node = Node2D.new(); stage_node.name = "Stage"; add_child(stage_node)
    var entry = stage_manifest[which]
    stage_meta = _read_json("res://" + String(entry["meta"]))
    var bg := Sprite2D.new(); bg.texture = load("res://" + String(entry["image"])); bg.centered = false; bg.z_index = -10; stage_node.add_child(bg)
    _build_collisions(stage_meta.get("collision",[]))
    _create_or_move_player(spawn)
    _configure_camera()
    _spawn_stage_entities(which)
    var bpath := String(entry.get("bgm",""))
    if not bpath.is_empty(): _play_bgm("res://" + bpath)
    stage_label.text = "%s  [Scene %d]" % [String(entry["name"]), int(entry["scene_id"])]
    _flash_message(String(entry["name"]))
    _update_hud()

func _clear_dynamic_entities() -> void:
    enemies.clear()
    breakables.clear()
    pickups.clear()
    projectiles.clear()
    save_points.clear()
    boss = null
    if boss_bar:
        boss_bar.visible = false
    if boss_label:
        boss_label.visible = false

func _build_collisions(cells: Array) -> void:
    var body := StaticBody2D.new(); body.collision_layer = 1; body.collision_mask = 0; body.name = "WorldCollision"; stage_node.add_child(body)
    for c in cells:
        var cx := float(c["x"]); var cy := float(c["y"]); var mask := int(c["mask"])
        if mask == 15:
            _add_box_collision(body,Vector2(cx*32+16,cy*32+16),Vector2(32,32))
        else:
            if (mask & 1) != 0: _add_box_collision(body,Vector2(cx*32+16,cy*32+2),Vector2(32,4))
            if (mask & 2) != 0: _add_box_collision(body,Vector2(cx*32+30,cy*32+16),Vector2(4,32))
            if (mask & 4) != 0: _add_box_collision(body,Vector2(cx*32+16,cy*32+30),Vector2(32,4))
            if (mask & 8) != 0: _add_box_collision(body,Vector2(cx*32+2,cy*32+16),Vector2(4,32))

func _add_box_collision(parent: Node, pos: Vector2, size: Vector2) -> void:
    var sh := RectangleShape2D.new(); sh.size = size
    var cs := CollisionShape2D.new(); cs.position = pos; cs.shape = sh; parent.add_child(cs)

func _create_or_move_player(spawn: Vector2) -> void:
    if not player or not is_instance_valid(player):
        player = CharacterBody2D.new(); player.name = "ほんにょん"; player.collision_layer = 2; player.collision_mask = 1; add_child(player)
        var col := CollisionShape2D.new(); var sh := CapsuleShape2D.new(); sh.radius = 26; sh.height = 104; col.shape = sh; col.position = Vector2(0,-52); player.add_child(col)
        player_sprite = AnimatedSprite2D.new(); player_sprite.sprite_frames = player_frames; player_sprite.position = Vector2(0,-144); player_sprite.play("idle"); player.add_child(player_sprite)
        attack_area = Area2D.new(); attack_area.collision_layer = 8; attack_area.collision_mask = 4; attack_area.monitoring = true
        var ac := CollisionShape2D.new(); var ash := RectangleShape2D.new(); ash.size = Vector2(150,110); ac.shape = ash; ac.disabled = true; attack_area.add_child(ac); player.add_child(attack_area)
    player.position = spawn; player.velocity = Vector2.ZERO; state = "normal"; state_timer = 0.0; invuln_timer = 0.0; jump_count = 0

func _configure_camera() -> void:
    if not camera or not is_instance_valid(camera):
        camera = Camera2D.new(); camera.position_smoothing_enabled = true; camera.position_smoothing_speed = 8.0; player.add_child(camera); camera.make_current()
    camera.limit_left = 0; camera.limit_top = 0; camera.limit_right = int(stage_meta.get("width",1280)); camera.limit_bottom = int(stage_meta.get("height",800))

func _spawn_stage_entities(which: String) -> void:
    for e in entities_root.get(which,[]):
        var kind := String(e.get("kind","")); var part_id := int(e.get("part_id",-1)); var ckey := "%s:%d" % [which,part_id]
        if collected.has(ckey): continue
        var pos := Vector2(float(e["x"]),float(e["y"])); var scale_v := float(e.get("scale_x",100))/100.0
        if kind.begins_with("enemy_"):
            _create_enemy(kind,pos,int(e.get("source_max_hp",1)),scale_v)
        elif kind in ["balloon","box","barrel"]:
            _create_breakable(kind,pos,scale_v)
        elif kind == "save_statue":
            _create_save_statue(pos)
        elif kind.begins_with("item_"):
            _create_pickup(kind.trim_prefix("item_"),pos,scale_v,ckey)
        elif kind.begins_with("boss_") and not bool(flags.get(kind,false)):
            _create_special_boss(kind,pos,scale_v)
    if which == "crab_boss" and bool(flags.get("boss_crab",false)) and not bool(flags.get("head",false)):
        _create_pickup("head",Vector2(856,474),1.0,"boss_reward_head")
    elif which == "harvester_boss" and bool(flags.get("boss_harvester",false)) and not bool(flags.get("body",false)):
        _create_pickup("body",Vector2(809,1115),1.0,"boss_reward_body")
    elif which == "chamber_boss" and bool(flags.get("boss_chamber",false)) and not bool(flags.get("hands",false)):
        _create_pickup("hands",Vector2(1531,647),1.0,"boss_reward_hands")

func _create_enemy(kind: String, pos: Vector2, source_hp: int, scale_v: float) -> void:
    var b := CharacterBody2D.new(); b.name = kind; b.position = pos; b.collision_layer = 4; b.collision_mask = 1; stage_node.add_child(b)
    var sh := CapsuleShape2D.new(); sh.radius = 26; sh.height = 86; var cs := CollisionShape2D.new(); cs.shape = sh; cs.position = Vector2(0,-42); b.add_child(cs)
    var sp := Sprite2D.new()
    var vis = enemy_visuals.get(kind,{})
    var file := String(vis.get("file",""))
    if not file.is_empty():
        sp.texture = load("res://"+file)
    var visual_height := 70.0
    if sp.texture:
        visual_height = float(sp.texture.get_height()) * 0.45
    sp.position = Vector2(0,-maxf(55.0,visual_height))
    sp.scale = Vector2(scale_v,scale_v)
    b.add_child(sp)
    b.set_meta("kind",kind); b.set_meta("hp",maxi(1,source_hp)); b.set_meta("max_hp",maxi(1,source_hp)); b.set_meta("dir",-1.0); b.set_meta("cooldown",randf_range(0.2,1.0)); b.set_meta("hurt",0.0)
    b.set_meta("flying",kind in ["enemy_b","enemy_c","enemy_h","enemy_n"]); b.set_meta("home_y",pos.y)
    enemies.append(b)

func _create_special_boss(kind: String, pos: Vector2, scale_v: float) -> void:
    var spec = {
        "boss_crab":{"name":"ボス　かに","hp":700,"frames":boss_frames,"idle":"crab_idle","reward":"head"},
        "boss_harvester":{"name":"ボス　はーべすたー","hp":3600,"frames":harvester_frames,"idle":"harvester_idle","reward":"body"},
        "boss_chamber":{"name":"チャンバー","hp":1420,"frames":chamber_frames,"idle":"chamber_idle","reward":"hands"},
        "boss_black":{"name":"黒にょん","hp":1200,"frames":black_frames,"idle":"black_standby","reward":""}
    }.get(kind,{})
    if spec.is_empty():
        return
    boss = CharacterBody2D.new()
    boss.name = String(spec["name"])
    boss.position = pos
    boss.collision_layer = 4
    boss.collision_mask = 1
    stage_node.add_child(boss)
    var sh := CapsuleShape2D.new()
    sh.radius = 95 if kind == "boss_chamber" else 72
    sh.height = 210 if kind == "boss_chamber" else 180
    var cs := CollisionShape2D.new()
    cs.shape = sh
    cs.position = Vector2(0,-80)
    boss.add_child(cs)
    var sp := AnimatedSprite2D.new()
    sp.sprite_frames = spec["frames"]
    sp.position = Vector2(0,-230)
    sp.scale = Vector2(scale_v,scale_v)
    sp.play(String(spec["idle"]))
    boss.add_child(sp)
    boss.set_meta("kind",kind)
    boss.set_meta("display_name",String(spec["name"]))
    boss.set_meta("hp",int(spec["hp"]))
    boss.set_meta("max_hp",int(spec["hp"]))
    boss.set_meta("reward",String(spec["reward"]))
    boss.set_meta("hurt",0.0)
    var program = boss_programs_v6.get(kind,{})
    var initial_action := int(program.get("initial_action_id",1))
    boss.set_meta("pg_action_id",initial_action)
    boss.set_meta("pg_elapsed",0.0)
    boss.set_meta("pg_entered",false)
    boss.set_meta("pg_variables",program.get("initial_variables",{}).duplicate(true))
    boss.set_meta("pg_switches",program.get("initial_switches",{}).duplicate(true))
    boss.set_meta("pg_move_remaining",0.0)
    boss.set_meta("pg_move_dir",Vector2.ZERO)
    boss.set_meta("pg_move_speed",0.0)
    boss.set_meta("pg_command_wait",0.0)
    boss.set_meta("pg_facing",1.0)
    boss.set_meta("pg_damage_event",false)
    boss_bar.visible = true
    boss_label.visible = true
    boss_bar.max_value = int(spec["hp"])
    boss_bar.value = int(spec["hp"])
    boss_label.text = "%s  %d / %d" % [String(spec["name"]),int(spec["hp"]),int(spec["hp"])]
    if boss_action_label:
        boss_action_label.visible = true

func _create_breakable(kind: String, pos: Vector2, scale_v: float) -> void:
    var b := CharacterBody2D.new(); b.name = kind; b.position = pos; b.collision_layer = 4; b.collision_mask = 0; stage_node.add_child(b)
    var sh := RectangleShape2D.new(); sh.size = Vector2(58,58); var cs := CollisionShape2D.new(); cs.shape = sh; cs.position = Vector2(0,-28); b.add_child(cs)
    var sp := AnimatedSprite2D.new(); sp.sprite_frames = item_frames; sp.position = Vector2(0,-144); sp.scale = Vector2(scale_v,scale_v); sp.play("box" if kind=="barrel" else kind); b.add_child(sp)
    b.set_meta("kind",kind); b.set_meta("hp",1); breakables.append(b)

func _create_save_statue(pos: Vector2) -> void:
    save_points.append(pos)
    var sp := AnimatedSprite2D.new(); sp.sprite_frames = item_frames; sp.position = pos + Vector2(0,-144); sp.play("save_statue"); stage_node.add_child(sp)

func _create_pickup(kind: String, pos: Vector2, scale_v := 1.0, collect_key := "") -> void:
    var a := Area2D.new(); a.name = "pickup_"+kind; a.position = pos; a.collision_layer = 0; a.collision_mask = 2; a.monitoring = true; stage_node.add_child(a)
    var sh := CircleShape2D.new(); sh.radius = 34; var cs := CollisionShape2D.new(); cs.shape = sh; cs.position = Vector2(0,-30); a.add_child(cs)
    var sp := Sprite2D.new()
    var vis = item_visuals.get(kind,{})
    var file := String(vis.get("file",""))
    if not file.is_empty():
        sp.texture = load("res://"+file)
    sp.position = Vector2(0,-80); sp.scale = Vector2(scale_v,scale_v); a.add_child(sp)
    a.set_meta("kind",kind); a.set_meta("collect_key",collect_key); a.body_entered.connect(_on_pickup_body_entered.bind(a)); pickups.append(a)

func _on_pickup_body_entered(body: Node, pickup: Area2D) -> void:
    if body != player or not is_instance_valid(pickup): return
    var kind := String(pickup.get_meta("kind","")); var ckey := String(pickup.get_meta("collect_key",""))
    if kind == "heart": player_hp = mini(player_max_hp,player_hp+20); _flash_message("HEART +20")
    elif kind == "credit": credits += 50; _flash_message("CREDIT +50")
    elif kind == "credit_big": credits += 200; _flash_message("CREDIT +200")
    elif kind == "max_hp": player_max_hp += 20; player_hp = player_max_hp; _flash_message("最大HP +20 • %d" % player_max_hp)
    elif kind == "turtle": flags["turtle"] = true; _flash_message("亀にょん 획득")
    elif kind == "turtle_jump": flags["turtle_jump"] = true; _flash_message("亀にょんジャンプ 획득 • 2단 점프 사용 가능")
    elif kind == "map": flags["map"] = true; _flash_message("地図 획득")
    elif kind == "candle": flags["candle"] = true; _flash_message("ろうそく 획득")
    elif kind == "ufo": flags["ufo"] = true; _flash_message("UFO 획득")
    elif kind == "ps5": flags["ps5"] = true; _flash_message("PS5 획득")
    elif kind == "alcohol": alcohol += 1; _flash_message("お酒 +1")
    elif kind in ["head","body","hands","feet"]:
        flags[kind] = true
        _flash_message("장비 획득: " + {"head":"頭","body":"体","hands":"手","feet":"足"}[kind])
    if not ckey.is_empty(): collected[ckey] = true
    _play_sfx("res://assets/audio/item_get.ogg")
    pickup.queue_free(); pickups.erase(pickup); _update_hud(); _update_inventory_text()

func _physics_process(delta: float) -> void:
    if not player: return
    portal_lock = maxf(0.0,portal_lock-delta); invuln_timer = maxf(0.0,invuln_timer-delta); state_timer = maxf(0.0,state_timer-delta); combo_window = maxf(0.0,combo_window-delta)
    if state != "normal" and state_timer <= 0.0:
        state = "normal"; (attack_area.get_child(0) as CollisionShape2D).set_deferred("disabled",true)
    if player.is_on_floor(): jump_count = 0
    if not player.is_on_floor(): player.velocity.y += GRAVITY*delta
    if state == "dash": player.velocity.x = facing*DASH_SPEED
    elif state == "dodge": player.velocity.x = facing*DODGE_SPEED
    elif state.begins_with("attack") or state.begins_with("strong") or state == "damage": player.velocity.x = move_toward(player.velocity.x,0.0,1300.0*delta)
    else:
        var axis := Input.get_axis("move_left","move_right")
        if absf(axis)>0.01: facing = signf(axis); player.velocity.x = axis*MOVE_SPEED
        else: player.velocity.x = move_toward(player.velocity.x,0.0,1300.0*delta)
        if Input.is_action_just_pressed("jump"):
            var can_double := bool(flags.get("turtle_jump",false)) and jump_count < 2
            if player.is_on_floor() or can_double:
                player.velocity.y = JUMP_VELOCITY; jump_count += 1; _play_sfx("res://assets/audio/jump.ogg")
        if Input.is_action_just_pressed("attack"): _begin_attack(false)
        elif Input.is_action_just_pressed("strong_attack"): _begin_attack(true)
        elif Input.is_action_just_pressed("dash"): state = "dash"; state_timer = 0.22; player_sprite.play("dash")
        elif Input.is_action_just_pressed("dodge"): state = "dodge"; state_timer = 0.32; invuln_timer = 0.42; player_sprite.play("dodge")
    if Input.is_action_just_pressed("interact"): _try_save_at_statue()
    if Input.is_action_just_pressed("save_game"): _save_game(false)
    if Input.is_action_just_pressed("load_game"): _load_game()
    if Input.is_action_just_pressed("inventory"): _toggle_inventory()
    player.move_and_slide(); player_sprite.flip_h = facing < 0; attack_area.position = Vector2(78*facing,-55)
    _process_attack_hits(); _update_player_animation(); _update_enemies(delta); _update_boss(delta); _update_projectiles(delta); _check_portals(); _update_save_hint()
    if player.position.y > float(stage_meta.get("height",800))+250.0: _respawn_checkpoint()

func _begin_attack(strong: bool) -> void:
    attack_hit_ids.clear(); (attack_area.get_child(0) as CollisionShape2D).set_deferred("disabled",false)
    if strong:
        state = "strong1"; state_timer = 0.42; combo_step = 0; player_sprite.play("strong1")
    else:
        combo_step = combo_step+1 if combo_window>0.0 and combo_step<3 else 1
        combo_window = 0.48; state = "attack%d" % combo_step; state_timer = 0.30; player_sprite.play("attack%d" % combo_step)
    _play_sfx("res://assets/audio/swing.ogg")

func _attack_damage() -> int:
    var base := 20 if state.begins_with("strong") else 10
    if bool(flags.get("hands",false)): base += 20
    return base

func _process_attack_hits() -> void:
    if not (state.begins_with("attack") or state.begins_with("strong")): return
    for body in attack_area.get_overlapping_bodies():
        if not is_instance_valid(body): continue
        var iid := body.get_instance_id()
        if attack_hit_ids.has(iid):
            continue
        attack_hit_ids[iid] = true
        var kind := String(body.get_meta("kind",""))
        if kind.begins_with("boss_"): _damage_boss(_attack_damage())
        elif kind.begins_with("enemy_"): _damage_enemy(body,_attack_damage())
        elif kind in ["balloon","box","barrel"]: _break_object(body)

func _damage_enemy(body: CharacterBody2D, amount: int) -> void:
    var hp := int(body.get_meta("hp",1))-amount; body.set_meta("hp",hp); body.set_meta("hurt",0.18); body.velocity.x = facing*280.0; body.velocity.y = -110.0; _play_sfx("res://assets/audio/hit.ogg")
    if hp <= 0:
        var p := body.position; body.queue_free(); enemies.erase(body)
        if randf()<0.45: _create_runtime_drop("credit",p)
        elif randf()<0.35: _create_runtime_drop("heart",p)

func _damage_boss(amount: int) -> void:
    if not boss or not is_instance_valid(boss): return
    var max_hp := int(boss.get_meta("max_hp",1)); var hp := int(boss.get_meta("hp",max_hp))-amount; boss.set_meta("hp",hp); boss.set_meta("hurt",0.20)
    boss.set_meta("pg_damage_event",true)
    _pg_sync_system_variables()
    var kind := String(boss.get_meta("kind","")); var sp := boss.get_child(1) as AnimatedSprite2D
    var hurt_anim := {"boss_crab":"crab_hurt","boss_chamber":"chamber_hurt"}.get(kind,"")
    if not String(hurt_anim).is_empty() and sp.sprite_frames.has_animation(String(hurt_anim)): sp.play(String(hurt_anim))
    boss_bar.value=maxi(0,hp); boss_label.text="%s  %d / %d" % [String(boss.get_meta("display_name","BOSS")),maxi(0,hp),max_hp]; _play_sfx("res://assets/audio/hit.ogg")
    if hp<=0:
        flags[kind]=true; var p:=boss.position; var reward:=String(boss.get_meta("reward","")); var name:=String(boss.get_meta("display_name","BOSS")); boss.queue_free(); boss=null; boss_bar.visible=false; boss_label.visible=false
        if reward.is_empty(): _flash_message(name+" 격파")
        else:
            var jp={"head":"頭","body":"体","hands":"手","feet":"足"}.get(reward,reward); _flash_message(name+" 격파 • 원본 보상 "+String(jp)+" 생성"); _create_pickup(reward,p+Vector2(0,-120),1.0,"boss_reward_"+reward)
        _update_inventory_text()

func _create_runtime_drop(kind: String, pos: Vector2) -> void:
    var a := Area2D.new(); a.position = pos; a.collision_layer = 0; a.collision_mask = 2; a.monitoring = true; stage_node.add_child(a)
    var sh := CircleShape2D.new(); sh.radius = 28; var cs := CollisionShape2D.new(); cs.shape = sh; cs.position = Vector2(0,-25); a.add_child(cs)
    var sp := AnimatedSprite2D.new(); sp.sprite_frames = item_frames; sp.position = Vector2(0,-144); sp.play(kind); a.add_child(sp)
    a.set_meta("kind",kind); a.set_meta("collect_key",""); a.body_entered.connect(_on_pickup_body_entered.bind(a)); pickups.append(a)

func _break_object(body: CharacterBody2D) -> void:
    var kind := String(body.get_meta("kind")); var p := body.position
    if kind in ["box","barrel"]:
        _play_sfx("res://assets/audio/box_open.ogg")
        if randf()<0.75: _create_runtime_drop("credit",p+Vector2(-18,-24))
        if randf()<0.50: _create_runtime_drop("credit",p+Vector2(18,-24))
        if randf()<0.80: _create_runtime_drop("credit_big",p+Vector2(0,-58))
    else:
        _create_runtime_drop("heart" if randf()<0.5 else "credit",p+Vector2(0,-24))
    body.queue_free(); breakables.erase(body)

func _update_player_animation() -> void:
    if state != "normal": return
    if not player.is_on_floor():
        if player_sprite.animation != "jump": player_sprite.play("jump")
    elif absf(player.velocity.x)>20.0:
        if player_sprite.animation != "walk": player_sprite.play("walk")
    else:
        if player_sprite.animation != "idle": player_sprite.play("idle")

func _update_enemies(delta: float) -> void:
    for e in enemies.duplicate():
        if not is_instance_valid(e): continue
        var kind := String(e.get_meta("kind")); var hurt := maxf(0.0,float(e.get_meta("hurt",0.0))-delta); e.set_meta("hurt",hurt)
        var cooldown := maxf(0.0,float(e.get_meta("cooldown",0.0))-delta); e.set_meta("cooldown",cooldown)
        var dir := signf(player.position.x-e.position.x)
        if dir==0.0:
            dir=1.0
        var dist := e.position.distance_to(player.position); var flying := bool(e.get_meta("flying",false))
        if flying:
            e.position.y = move_toward(e.position.y,player.position.y-80.0,70.0*delta)
        elif not e.is_on_floor(): e.velocity.y += GRAVITY*delta
        if hurt <= 0.0:
            if kind in ["enemy_b","enemy_c","enemy_g","enemy_h","enemy_l","enemy_n"]:
                e.velocity.x = dir*35.0 if absf(player.position.x-e.position.x)>250.0 else 0.0
                if dist<600.0 and cooldown<=0.0: _enemy_shoot(e,8 if kind!="enemy_l" else 14,270.0,1.35)
            else:
                e.velocity.x = dir*(85.0 if kind in ["enemy_j","enemy_k"] else 65.0) if dist>95.0 else 0.0
                if dist<110.0 and cooldown<=0.0: _enemy_melee(e,10,1.0)
        if not flying: e.move_and_slide()
        else: e.position.x += e.velocity.x*delta
        var visual = e.get_child(1)
        if visual is Sprite2D:
            (visual as Sprite2D).flip_h = dir < 0.0
        if dist<45.0: _damage_player(5,dir)

func _update_boss(delta: float) -> void:
    if not boss or not is_instance_valid(boss):
        if boss_action_label:
            boss_action_label.visible = false
        return
    var hurt := maxf(0.0,float(boss.get_meta("hurt",0.0))-delta)
    boss.set_meta("hurt",hurt)
    _pg_sync_system_variables()
    _pg_update_action_runtime(delta)
    if not boss or not is_instance_valid(boss):
        return
    var kind := String(boss.get_meta("kind",""))
    var action := _pg_current_action()
    var ignore_gravity := bool(action.get("ignore_gravity",false))
    if kind != "boss_chamber" and not ignore_gravity and not boss.is_on_floor():
        boss.velocity.y += GRAVITY*delta
    if kind != "boss_chamber":
        boss.move_and_slide()
    _pg_sync_system_variables()
    var dir := signf(player.position.x-boss.position.x)
    if dir == 0.0:
        dir = 1.0
    var contact_damage := 18
    if kind == "boss_harvester":
        contact_damage = 30
    elif kind == "boss_black":
        contact_damage = 23
    elif kind == "boss_chamber":
        contact_damage = 12
    if boss.position.distance_to(player.position) < 115.0:
        _damage_player(contact_damage,dir)

func _pg_program() -> Dictionary:
    if not boss or not is_instance_valid(boss):
        return {}
    return boss_programs_v6.get(String(boss.get_meta("kind","")),{})

func _pg_current_action() -> Dictionary:
    var program := _pg_program()
    if program.is_empty():
        return {}
    var action_id := int(boss.get_meta("pg_action_id",int(program.get("initial_action_id",1))))
    return program.get("actions",{}).get(str(action_id),{})

func _pg_change_action(action_id: int) -> void:
    if not boss or not is_instance_valid(boss):
        return
    boss.set_meta("pg_action_id",action_id)
    boss.set_meta("pg_elapsed",0.0)
    boss.set_meta("pg_entered",false)
    boss.set_meta("pg_command_wait",0.0)
    boss.set_meta("pg_move_remaining",0.0)

func _pg_update_action_runtime(delta: float) -> void:
    var program := _pg_program()
    if program.is_empty():
        return
    var action := _pg_current_action()
    if action.is_empty():
        return
    if _pg_run_common_actions(program):
        action = _pg_current_action()
    boss.set_meta("pg_damage_event",false)
    if not bool(boss.get_meta("pg_entered",false)):
        boss.set_meta("pg_entered",true)
        _pg_enter_action(action,program)
    var elapsed := float(boss.get_meta("pg_elapsed",0.0))+delta
    boss.set_meta("pg_elapsed",elapsed)
    var wait_left := maxf(0.0,float(boss.get_meta("pg_command_wait",0.0))-delta)
    boss.set_meta("pg_command_wait",wait_left)
    _pg_update_scripted_move(delta)
    _pg_update_action_trace(action)
    if wait_left > 0.0:
        return
    var links = program.get("links",{}).get(str(int(action.get("id",0))),[])
    for link in links:
        if _pg_link_passes(link):
            _pg_change_action(int(link.get("to",0)))
            return

func _pg_enter_action(action: Dictionary, program: Dictionary) -> void:
    var sp := boss.get_child(1) as AnimatedSprite2D
    var motion_id := str(int(action.get("anim_motion_id",-1)))
    var anim_name := String(program.get("motion_animation_map",{}).get(motion_id,""))
    if not anim_name.is_empty() and sp.sprite_frames.has_animation(anim_name):
        sp.play(anim_name)
    for cmd in action.get("commands",[]):
        _pg_execute_command(cmd,action,program)

func _pg_execute_command(cmd: Dictionary, action: Dictionary, program: Dictionary) -> void:
    var t := int(cmd.get("type",-1))
    if t == 38:
        var d = cmd.get("directionMove",{})
        var deg := float(d.get("direction",0.0))
        var vec := _pg_angle_vector(deg)
        var speed := maxf(60.0,float(action.get("move_speed",100.0)))
        var dist := float(d.get("moveDistance",0.0))
        if bool(d.get("moveDistanceEnabled",false)) and dist > 0.0:
            boss.set_meta("pg_move_dir",vec)
            boss.set_meta("pg_move_remaining",dist)
            boss.set_meta("pg_move_speed",speed)
        else:
            boss.velocity = vec*speed
    elif t == 4:
        _pg_execute_object_move(cmd.get("objectMove",{}),action)
    elif t == 9:
        _pg_fire_source_bullet(int(cmd.get("bulletFire",{}).get("bulletId",1)),program)
    elif t == 31:
        _pg_apply_switch_variable(cmd.get("switchVariableChange",{}))
    elif t == 25:
        var snd = cmd.get("soundPlay",{})
        if int(snd.get("soundType",0)) == 0:
            _pg_play_source_se(int(snd.get("seId",-1)))
    elif t == 2:
        _pg_create_source_object(cmd.get("objectCreate",{}))
    elif t == 34:
        var w = cmd.get("wait",{})
        boss.set_meta("pg_command_wait",maxf(float(boss.get_meta("pg_command_wait",0.0)),float(w.get("duration300",0.0))/300.0))
    elif t == 54:
        var rev := bool(cmd.get("displayDirectionMove",{}).get("reverse",false))
        if rev:
            boss.set_meta("pg_facing",-float(boss.get_meta("pg_facing",1.0)))
    elif t == 40:
        var exec = cmd.get("actionExec",{})
        var target_action := int(exec.get("actionId",-1))
        if target_action >= 0:
            _pg_change_action(target_action)
    elif t == 43:
        var shake = cmd.get("sceneShake",{})
        if camera:
            camera.position = Vector2(randf_range(-float(shake.get("width",2)),float(shake.get("width",2))),randf_range(-float(shake.get("height",2)),float(shake.get("height",2))))
    elif t == 10:
        # Source disappearance is normally part of a death/event chain. V6 keeps the node alive until HP/reward handling completes.
        boss.visible = true

func _pg_execute_object_move(m: Dictionary, action: Dictionary) -> void:
    var move_type := int(m.get("moveType",0))
    var duration := float(m.get("moveDuration300",300.0))/300.0
    var target := boss.position
    if move_type == 1:
        target = Vector2(float(m.get("posX",boss.position.x)),float(m.get("posY",boss.position.y)))
    elif move_type in [2,3,4]:
        target = player.position+Vector2(float(m.get("centerAdjustX",0.0)),float(m.get("centerAdjustY",0.0)))
    else:
        var vec := _pg_angle_vector(float(m.get("angle",0.0)))
        var dist := float(m.get("moveDistance",128.0))
        target = boss.position+vec*dist
    var delta_pos := target-boss.position
    if delta_pos.length() < 1.0:
        return
    if duration <= 0.05:
        boss.position = target
        boss.velocity = Vector2.ZERO
    else:
        boss.set_meta("pg_move_dir",delta_pos.normalized())
        boss.set_meta("pg_move_remaining",delta_pos.length())
        boss.set_meta("pg_move_speed",clampf(delta_pos.length()/duration,80.0,1800.0))

func _pg_update_scripted_move(delta: float) -> void:
    var rem := float(boss.get_meta("pg_move_remaining",0.0))
    if rem <= 0.0:
        return
    var dir: Vector2 = boss.get_meta("pg_move_dir",Vector2.ZERO)
    var speed := float(boss.get_meta("pg_move_speed",100.0))
    boss.velocity = dir*speed
    rem -= speed*delta
    boss.set_meta("pg_move_remaining",maxf(0.0,rem))
    if rem <= 0.0:
        boss.velocity = Vector2.ZERO

func _pg_angle_vector(deg: float) -> Vector2:
    var r := deg_to_rad(deg)
    # PGMMV: 0=up, 90=left, 180=down, 270=right.
    return Vector2(-sin(r),-cos(r)).normalized()

func _pg_link_passes(link: Dictionary) -> bool:
    return _pg_conditions_pass(link.get("conditions",[]))

func _pg_conditions_pass(conditions: Array) -> bool:
    if conditions.is_empty():
        return true
    # PGMMV: condAnd=true continues the current AND group; condAnd=false closes it. Groups are ORed.
    var group_result := true
    for cond in conditions:
        var value := _pg_eval_condition(cond)
        if bool(cond.get("not",false)):
            value = not value
        group_result = group_result and value
        if not bool(cond.get("and",true)):
            if group_result:
                return true
            group_result = true
    return group_result

func _pg_run_common_actions(program: Dictionary) -> bool:
    for common in program.get("common_actions",[]):
        if not _pg_conditions_pass(common.get("conditions",[])):
            continue
        var before := int(boss.get_meta("pg_action_id",-1))
        for cmd in common.get("commands",[]):
            _pg_execute_command(cmd,_pg_current_action(),program)
        if int(boss.get_meta("pg_action_id",-1)) != before:
            return true
    return false

func _pg_eval_condition(cond: Dictionary) -> bool:
    var t := int(cond.get("type",-1))
    if t == 16:
        return float(boss.get_meta("pg_elapsed",0.0)) >= float(cond.get("waitTime",{}).get("time",0.0))
    if t == 7:
        var c = cond.get("objectNear",{})
        var distance := boss.position.distance_to(player.position)
        var wanted := float(c.get("distance",0.0))
        var dt := int(c.get("distanceType",2))
        if dt == 1:
            return distance >= wanted
        if dt == 2:
            return distance <= wanted
        return true
    if t == 10:
        return boss.position.distance_to(player.position) <= 960.0
    if t == 12:
        return int(boss.get_meta("hp",1)) <= 0
    if t == 15:
        return randf()*100.0 < float(cond.get("probability",{}).get("probability",0.0))
    if t == 17:
        return _pg_eval_switch_variable(cond.get("switchVariableChanged",{}))
    if t == 18:
        var sp := boss.get_child(1) as AnimatedSprite2D
        if not sp.sprite_frames.has_animation(sp.animation):
            return true
        if sp.sprite_frames.get_animation_loop(sp.animation):
            return false
        return sp.frame >= sp.sprite_frames.get_frame_count(sp.animation)-1 and sp.frame_progress > 0.85
    if t == 0:
        var bit := int(cond.get("wallTouched",{}).get("wallBit",15))
        return _pg_wall_condition(bit)
    if t == 4:
        var bit2 := int(cond.get("objectWallTouched",{}).get("wallBit",15))
        return _pg_wall_condition(bit2)
    if t == 21:
        return boss.is_on_floor()
    if t == 5:
        return bool(boss.get_meta("pg_damage_event",false))
    if t == 20:
        var c2 = cond.get("objectActionChanged",{})
        var expected := int(c2.get("actionId",-999))
        var current := int(boss.get_meta("pg_action_id",-1))
        return current != expected if bool(c2.get("otherActions",false)) else current == expected
    return false

func _pg_wall_condition(bit: int) -> bool:
    var hit := false
    if (bit & 8) != 0:
        hit = hit or boss.is_on_floor()
    if (bit & 1) != 0:
        hit = hit or boss.is_on_ceiling()
    if (bit & 6) != 0:
        hit = hit or boss.is_on_wall()
    return hit

func _pg_eval_switch_variable(c: Dictionary) -> bool:
    var vars: Dictionary = boss.get_meta("pg_variables",{})
    var sw: Dictionary = boss.get_meta("pg_switches",{})
    if bool(c.get("swtch",false)):
        var sid := str(int(c.get("switchId",-1)))
        var value := bool(sw.get(sid,false))
        var mode := int(c.get("switchCondition",0))
        if mode == 0:
            return value
        if mode == 1:
            return not value
        return value
    var lhs := float(vars.get(str(int(c.get("variableId",-1))),0.0))
    var rhs := float(c.get("compareValue",0.0))
    if int(c.get("compareValueType",0)) == 1:
        var other_obj := int(c.get("compareVariableObjectId",-1))
        var other_id := int(c.get("compareVariableId",-1))
        if other_obj == 2:
            rhs = _pg_player_variable(other_id)
        else:
            rhs = float(vars.get(str(other_id),0.0))
    return _pg_compare(lhs,rhs,int(c.get("compareVariableOperator",2)))

func _pg_compare(a: float, b: float, op: int) -> bool:
    match op:
        0: return a < b
        1: return a <= b
        2: return is_equal_approx(a,b)
        3: return a >= b
        4: return a > b
        5: return not is_equal_approx(a,b)
    return false

func _pg_apply_switch_variable(c: Dictionary) -> void:
    var vars: Dictionary = boss.get_meta("pg_variables",{}).duplicate(true)
    var sw: Dictionary = boss.get_meta("pg_switches",{}).duplicate(true)
    if bool(c.get("swtch",false)):
        var sid := str(int(c.get("switchId",-1)))
        var mode := int(c.get("switchValue",0))
        if mode == 0:
            sw[sid] = true
        elif mode == 1:
            sw[sid] = false
        else:
            sw[sid] = not bool(sw.get(sid,false))
        boss.set_meta("pg_switches",sw)
        return
    var vid := str(int(c.get("variableId",-1)))
    var old := float(vars.get(vid,0.0))
    var value := float(c.get("assignValue",0.0))
    var value_type := int(c.get("variableAssignValueType",0))
    if value_type == 1:
        var src_obj := int(c.get("assignVariableObjectId",-1))
        var src_id := int(c.get("assignVariableId",-1))
        value = _pg_player_variable(src_id) if src_obj == 2 else float(vars.get(str(src_id),0.0))
    elif value_type == 2:
        value = randf_range(float(c.get("randomMin",0.0)),float(c.get("randomMax",100.0)))
    var op := int(c.get("variableAssignOperator",0))
    match op:
        0: old = value
        1: old += value
        2: old -= value
        3: old *= value
        4:
            if not is_zero_approx(value): old /= value
        5:
            if not is_zero_approx(value): old = fmod(old,value)
    vars[vid] = old
    boss.set_meta("pg_variables",vars)

func _pg_sync_system_variables() -> void:
    if not boss or not is_instance_valid(boss):
        return
    var vars: Dictionary = boss.get_meta("pg_variables",{}).duplicate(true)
    vars["2"] = int(boss.get_meta("hp",1))
    vars["3"] = int(boss.get_meta("max_hp",1))
    vars["9"] = boss.position.x
    vars["10"] = boss.position.y
    vars["11"] = boss.velocity.x
    vars["12"] = boss.velocity.y
    vars["37"] = float(boss.get_meta("pg_facing",1.0))
    boss.set_meta("pg_variables",vars)

func _pg_player_variable(id: int) -> float:
    match id:
        2: return float(player_hp)
        3: return float(player_max_hp)
        9: return player.position.x
        10: return player.position.y
        11: return player.velocity.x
        12: return player.velocity.y
    return 0.0

func _pg_fire_source_bullet(bullet_id: int, program: Dictionary) -> void:
    var b = program.get("bullets",{}).get(str(bullet_id),{})
    var count := maxi(1,int(b.get("dispBulletCount",1)))
    count = mini(count,8)
    var damage := int(round((float(program.get("min_attack",10))+float(program.get("max_attack",10)))*0.5))
    var toward := bool(b.get("towardPlayer",false)) or int(b.get("initialBulletLocus",0)) == 2
    var base_deg := float(b.get("oneDirectionAngle",0.0))
    var spread := float(b.get("oneDirectionSpreadRange",0.0))
    for i in range(count):
        var dir := (player.position+Vector2(0,-45)-boss.position).normalized() if toward else _pg_angle_vector(base_deg)
        if count > 1:
            var t := 0.5 if count == 1 else float(i)/float(count-1)
            var off := deg_to_rad(lerpf(-spread*0.5,spread*0.5,t))
            dir = dir.rotated(off)
        _pg_spawn_projectile(dir,damage,430.0)

func _pg_spawn_projectile(dir: Vector2, damage: int, speed: float) -> void:
    var p := Node2D.new()
    p.position = boss.position+Vector2(0,-85)
    p.set_meta("vel",dir.normalized()*speed)
    p.set_meta("damage",damage)
    p.set_meta("life",4.0)
    var poly := Polygon2D.new()
    poly.polygon = PackedVector2Array([Vector2(-9,0),Vector2(0,-9),Vector2(9,0),Vector2(0,9)])
    p.add_child(poly)
    stage_node.add_child(p)
    projectiles.append(p)

func _pg_create_source_object(c: Dictionary) -> void:
    var oid := int(c.get("objectId",-1))
    var chance := float(c.get("probability",100.0))
    if randf()*100.0 > chance:
        return
    var facts = pgmmv_program_root.get("created_objects",{}).get(str(oid),{})
    var hp := int(facts.get("hp",1))
    var damage := maxi(5,int(round((float(facts.get("min_attack",5))+float(facts.get("max_attack",5)))*0.5)))
    if hp > 1 and hp < 10000 and int(facts.get("group",-1)) == 1:
        # Helper/minion approximation: create a small hostile body using source HP and attack values.
        var e := CharacterBody2D.new()
        e.position = boss.position+Vector2(float(c.get("adjustX",0.0)),float(c.get("adjustY",0.0)))
        e.collision_layer = 4
        e.collision_mask = 1
        stage_node.add_child(e)
        var sh := CircleShape2D.new(); sh.radius = 24
        var cs := CollisionShape2D.new(); cs.shape = sh; cs.position = Vector2(0,-24); e.add_child(cs)
        var poly := Polygon2D.new(); poly.polygon = PackedVector2Array([Vector2(-20,0),Vector2(0,-40),Vector2(20,0)]); e.add_child(poly)
        e.set_meta("kind","enemy_runtime_helper")
        e.set_meta("hp",hp)
        e.set_meta("max_hp",hp)
        e.set_meta("dir",signf(player.position.x-e.position.x))
        e.set_meta("cooldown",0.3)
        e.set_meta("hurt",0.0)
        e.set_meta("flying",true)
        e.set_meta("home_y",e.position.y)
        enemies.append(e)
    else:
        var dir := (player.position-boss.position).normalized()
        _pg_spawn_projectile(dir,damage,380.0)

func _pg_play_source_se(se_id: int) -> void:
    var p := String(pgmmv_program_root.get("se_paths",{}).get(str(se_id),""))
    if not p.is_empty():
        _play_sfx("res://"+p)

func _pg_update_action_trace(action: Dictionary) -> void:
    if not boss_action_label:
        return
    boss_action_label.visible = true
    boss_action_label.text = "PGMMV  Action %d  %s  %.2fs" % [int(action.get("id",0)),String(action.get("name","")),float(boss.get_meta("pg_elapsed",0.0))]


func _enemy_melee(e: CharacterBody2D, damage: int, cooldown: float) -> void:
    e.set_meta("cooldown",cooldown); _damage_player(damage,signf(player.position.x-e.position.x))

func _enemy_shoot(e: CharacterBody2D, damage: int, speed: float, cooldown: float) -> void:
    e.set_meta("cooldown",cooldown)
    var p := Node2D.new(); p.position = e.position+Vector2(0,-55); p.set_meta("vel",(player.position+Vector2(0,-45)-p.position).normalized()*speed); p.set_meta("damage",damage); p.set_meta("life",4.0)
    var poly := Polygon2D.new(); poly.polygon = PackedVector2Array([Vector2(-8,0),Vector2(0,-8),Vector2(8,0),Vector2(0,8)]); p.add_child(poly); stage_node.add_child(p); projectiles.append(p); _play_sfx("res://assets/audio/fire.ogg")

func _update_projectiles(delta: float) -> void:
    for p in projectiles.duplicate():
        if not is_instance_valid(p): continue
        var life := float(p.get_meta("life",0.0))-delta; p.set_meta("life",life); p.position += p.get_meta("vel",Vector2.ZERO)*delta
        if p.position.distance_to(player.position+Vector2(0,-45))<34.0:
            _damage_player(int(p.get_meta("damage",5)),signf(player.position.x-p.position.x)); p.queue_free(); projectiles.erase(p)
        elif life<=0.0:
            p.queue_free(); projectiles.erase(p)

func _damage_player(amount: int, knock_dir: float) -> void:
    if invuln_timer>0.0 or state=="dodge": return
    invuln_timer=0.75; player_hp=maxi(0,player_hp-amount); state="damage"; state_timer=0.28; player_sprite.play("damage"); player.velocity.x=knock_dir*250.0; player.velocity.y=-170.0; _play_sfx("res://assets/audio/hit.ogg"); _update_hud()
    if player_hp<=0: _game_over()

func _game_over() -> void:
    _flash_message("GAME OVER • 체크포인트에서 재시작"); _respawn_checkpoint()

func _respawn_checkpoint() -> void:
    player_hp = player_max_hp
    if current_stage != checkpoint_stage: _load_stage(checkpoint_stage,checkpoint_pos)
    else: player.position = checkpoint_pos; player.velocity = Vector2.ZERO
    _update_hud()

func _check_portals() -> void:
    if portal_lock>0.0: return
    for p in portals_root.get("portals",[]):
        var areas = p.get("areas",[])
        if areas.size()!=2: continue
        for i in range(2):
            var a = areas[i]
            if String(a["stage"]) != current_stage: continue
            var rect := Rect2(float(a["x"]),float(a["y"]),float(a["width"]),float(a["height"]))
            if rect.grow(24.0).has_point(player.position):
                var target = areas[1-i]; var target_stage := String(target["stage"]); var spawn := Vector2(float(target["x"])+float(target["width"])/2.0,float(target["y"])+float(target["height"])/2.0)
                var tm = stage_manifest[target_stage]; var tmeta = _read_json("res://"+String(tm["meta"])); var tw := float(tmeta.get("width",1280)); var th := float(tmeta.get("height",800))
                if spawn.x<80.0: spawn.x += 90.0
                elif spawn.x>tw-80.0: spawn.x -= 90.0
                if spawn.y<80.0: spawn.y += 90.0
                elif spawn.y>th-80.0: spawn.y -= 90.0
                _load_stage(target_stage,spawn); return

func _try_save_at_statue() -> void:
    for p in save_points:
        if player.position.distance_to(p)<130.0:
            checkpoint_stage=current_stage; checkpoint_pos=player.position; _save_game(true); player_sprite.play("save_pose"); return
    _flash_message("석상 가까이에서 USE/E")

func _save_game(from_statue: bool) -> void:
    if not from_statue:
        var near := false
        for p in save_points:
            if player.position.distance_to(p)<130.0: near=true
        if not near: _flash_message("SAVE: 석상 근처에서만 가능"); return
    var payload = {"version":7,"stage":current_stage,"x":player.position.x,"y":player.position.y,"hp":player_hp,"max_hp":player_max_hp,"credits":credits,"alcohol":alcohol,"flags":flags,"collected":collected,"checkpoint_stage":current_stage,"checkpoint_x":player.position.x,"checkpoint_y":player.position.y}
    var f := FileAccess.open(SAVE_PATH,FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(payload)); checkpoint_stage=current_stage; checkpoint_pos=player.position; _flash_message("SAVE 완료")

func _load_game() -> void:
    var load_path := SAVE_PATH
    var migrated := false
    if not FileAccess.file_exists(load_path):
        if FileAccess.file_exists(LEGACY_SAVE_PATH):
            load_path = LEGACY_SAVE_PATH
            migrated = true
        else:
            _flash_message("V7/V6 저장 데이터 없음")
            return
    var f := FileAccess.open(load_path,FileAccess.READ)
    var d = JSON.parse_string(f.get_as_text()) if f else {}
    if typeof(d) != TYPE_DICTIONARY:
        _flash_message("저장 데이터 파싱 실패")
        return
    player_hp=int(d.get("hp",100)); player_max_hp=int(d.get("max_hp",100)); credits=int(d.get("credits",100)); alcohol=int(d.get("alcohol",0)); flags=d.get("flags",flags); collected=d.get("collected",{}); checkpoint_stage=String(d.get("checkpoint_stage",d.get("stage","outside"))); checkpoint_pos=Vector2(float(d.get("checkpoint_x",d.get("x",2002))),float(d.get("checkpoint_y",d.get("y",453))))
    _load_stage(String(d.get("stage","outside")),Vector2(float(d.get("x",2002)),float(d.get("y",453))))
    if migrated:
        _save_game_migrated()
        _flash_message("V6 저장 → V7 이관 완료")
    else:
        _flash_message("LOAD 완료")
    _update_inventory_text()

func _save_game_migrated() -> void:
    var payload = {"version":7,"stage":current_stage,"x":player.position.x,"y":player.position.y,"hp":player_hp,"max_hp":player_max_hp,"credits":credits,"alcohol":alcohol,"flags":flags,"collected":collected,"checkpoint_stage":checkpoint_stage,"checkpoint_x":checkpoint_pos.x,"checkpoint_y":checkpoint_pos.y}
    var f := FileAccess.open(SAVE_PATH,FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(payload))

func _update_save_hint() -> void:
    if not save_hint: return
    save_hint.text=""
    for p in save_points:
        if player.position.distance_to(p)<130.0: save_hint.text="USE / E : SAVE"; return

func _play_bgm(path: String) -> void:
    var stream = load(path)
    if bgm.stream==stream and bgm.playing: return
    bgm.stop(); bgm.stream=stream
    if stream:
        if stream is AudioStreamOggVorbis: stream.set("loop",true)
        bgm.volume_db=-7.0; bgm.play()

func _play_sfx(path: String) -> void:
    var stream=load(path)
    if stream:
        sfx.stream=stream
        sfx.play()

func _create_ui() -> void:
    var layer:=CanvasLayer.new(); layer.layer=20; add_child(layer)
    var title:=Label.new(); title.text="ホンブギの冒険  Android Port V7"; title.position=Vector2(24,16); title.add_theme_font_size_override("font_size",20); layer.add_child(title)
    stage_label=Label.new(); stage_label.position=Vector2(370,16); stage_label.add_theme_font_size_override("font_size",18); layer.add_child(stage_label)
    hp_bar=ProgressBar.new(); hp_bar.position=Vector2(24,48); hp_bar.size=Vector2(310,24); hp_bar.show_percentage=false; layer.add_child(hp_bar)
    hp_label=Label.new(); hp_label.position=Vector2(34,49); hp_label.add_theme_font_size_override("font_size",16); layer.add_child(hp_label)
    credit_label=Label.new(); credit_label.position=Vector2(355,48); credit_label.add_theme_font_size_override("font_size",17); layer.add_child(credit_label)
    ui_message=Label.new(); ui_message.position=Vector2(24,78); ui_message.add_theme_font_size_override("font_size",17); layer.add_child(ui_message)
    save_hint=Label.new(); save_hint.position=Vector2(535,76); save_hint.size=Vector2(250,32); save_hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; save_hint.add_theme_font_size_override("font_size",18); layer.add_child(save_hint)
    boss_bar=ProgressBar.new(); boss_bar.position=Vector2(390,120); boss_bar.size=Vector2(500,26); boss_bar.show_percentage=false; boss_bar.visible=false; layer.add_child(boss_bar)
    boss_label=Label.new(); boss_label.position=Vector2(390,148); boss_label.size=Vector2(500,28); boss_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; boss_label.visible=false; layer.add_child(boss_label)
    boss_action_label=Label.new(); boss_action_label.position=Vector2(390,176); boss_action_label.size=Vector2(500,24); boss_action_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; boss_action_label.add_theme_font_size_override("font_size",14); boss_action_label.visible=false; layer.add_child(boss_action_label)
    inventory_panel=Panel.new(); inventory_panel.position=Vector2(810,120); inventory_panel.size=Vector2(430,360); inventory_panel.visible=false; layer.add_child(inventory_panel)
    inventory_text=Label.new(); inventory_text.position=Vector2(18,15); inventory_text.size=Vector2(395,330); inventory_text.add_theme_font_size_override("font_size",17); inventory_panel.add_child(inventory_text); _update_inventory_text()
    _touch_button(layer,"◀",Vector2(95,690),"move_left",58); _touch_button(layer,"▶",Vector2(235,690),"move_right",58)
    _touch_button(layer,"JUMP",Vector2(1010,650),"jump",52); _touch_button(layer,"ATK",Vector2(1150,690),"attack",52); _touch_button(layer,"STR",Vector2(1160,565),"strong_attack",48); _touch_button(layer,"DODGE",Vector2(890,700),"dodge",48); _touch_button(layer,"DASH",Vector2(905,590),"dash",45)
    _touch_button(layer,"USE",Vector2(1080,455),"interact",40); _touch_button(layer,"SAVE",Vector2(70,130),"save_game",34); _touch_button(layer,"LOAD",Vector2(155,130),"load_game",34); _touch_button(layer,"INV",Vector2(240,130),"inventory",34)

func _touch_button(layer: CanvasLayer, text: String, pos: Vector2, action: String, radius: float) -> void:
    var b:=TouchScreenButton.new(); b.position=pos; b.action=action; var shape:=CircleShape2D.new(); shape.radius=radius; b.shape=shape; b.visibility_mode=TouchScreenButton.VISIBILITY_ALWAYS; layer.add_child(b)
    var lab:=Label.new(); lab.text=text; lab.position=pos-Vector2(radius,15); lab.size=Vector2(radius*2,34); lab.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; lab.mouse_filter=Control.MOUSE_FILTER_IGNORE; lab.add_theme_font_size_override("font_size",16); layer.add_child(lab)
    var ring:=Control.new(); ring.position=pos-Vector2(radius,radius); ring.size=Vector2(radius*2,radius*2); ring.mouse_filter=Control.MOUSE_FILTER_IGNORE; ring.set_meta("radius",radius); ring.set_script(preload("res://scripts/touch_ring.gd")); layer.add_child(ring)

func _toggle_inventory() -> void:
    inventory_panel.visible = not inventory_panel.visible; _update_inventory_text()

func _update_inventory_text() -> void:
    if not inventory_text: return
    inventory_text.text = "[V7 SOURCE INVENTORY]\n\n장비  頭:%s  体:%s  手:%s  足:%s\n\n亀にょん: %s\n亀ジャンプ: %s\n地図: %s   ろうそく: %s\nUFO: %s   PS5: %s\nお酒: %d\n\n보스  かに:%s  ハーベスター:%s  チャンバー:%s  黒にょん:%s\n\n※ 手 장비의 원본 명령: 공격력 증가분=20" % [_yn("head"),_yn("body"),_yn("hands"),_yn("feet"),_yn("turtle"),_yn("turtle_jump"),_yn("map"),_yn("candle"),_yn("ufo"),_yn("ps5"),alcohol,_yn("boss_crab"),_yn("boss_harvester"),_yn("boss_chamber"),_yn("boss_black")]

func _yn(k: String) -> String:
    return "O" if bool(flags.get(k,false)) else "-"

func _update_hud() -> void:
    if hp_bar: hp_bar.max_value=player_max_hp; hp_bar.value=player_hp
    if hp_label: hp_label.text="HP %d / %d" % [player_hp,player_max_hp]
    if credit_label: credit_label.text="CREDIT  %d" % credits

func _flash_message(msg: String) -> void:
    if ui_message: ui_message.text=msg
