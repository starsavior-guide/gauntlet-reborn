extends Control
func _draw() -> void:
    var radius:=float(get_meta("radius",58.0))
    draw_circle(Vector2(radius,radius),radius-2.0,Color(1,1,1,0.11))
    draw_arc(Vector2(radius,radius),radius-2.0,0,TAU,48,Color(1,1,1,0.34),2.0)
func _ready() -> void:
    queue_redraw()
