# Honbugi Adventure Android Port V7

V7 keeps the V6 world slice and PGMMV boss action-graph runtime and hardens the project for a real Android debug APK build.

Changes: Android orientation fixed to landscape (`0`), V7 save with automatic V6-save migration, `build/HonbugiV7.apk` export target, static preflight, one-command headless build script, and a GitHub Actions Android debug build using `barichello/godot-ci:4.7.2`.

Run `python3 tools/preflight_v7.py` for static integrity checks. In an environment with Godot 4.7.2 + Android export support, run `./tools/build_android_v7.sh` to import/parse the project and export `build/HonbugiV7.apk`.
