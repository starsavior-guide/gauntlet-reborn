#!/usr/bin/env python3
"""Extract the PGMMV boss action graph used by V6.
Run from repository root: python tools/extract_pgmmv_actions_v6.py /path/to/project.json
This file documents the V6 extraction schema; the distributed JSON is already generated.
"""
import json, sys, pathlib
BOSSES={"boss_crab":74,"boss_harvester":101,"boss_chamber":111,"boss_black":158}
def main(path):
    p=json.load(open(path,encoding="utf8")); objs={o["id"]:o for o in p["objectList"] if not o.get("folder",False)}
    for kind,oid in BOSSES.items():
        o=objs[oid]
        print(kind, o["name"], "actions",len(o["actionList"]),"links",len(o["actionLinkList"]),"initial",o["initialActionId"])
if __name__=="__main__": main(sys.argv[1])
