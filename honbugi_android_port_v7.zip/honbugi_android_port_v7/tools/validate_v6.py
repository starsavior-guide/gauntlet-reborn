#!/usr/bin/env python3
import json, pathlib, re, sys, collections
root=pathlib.Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
program=json.load(open(root/'data/pgmmv_boss_programs_v6.json',encoding='utf8'))
manifest=json.load(open(root/'data/stage_manifest_v5.json',encoding='utf8'))
portals=json.load(open(root/'data/portals_v5.json',encoding='utf8'))['portals']
entities=json.load(open(root/'data/entities_v5.json',encoding='utf8'))
motion_report=json.load(open(root/'data/v6_motion_extraction_report.json',encoding='utf8'))
animfiles={'boss_crab':'boss_crab_animations.json','boss_harvester':'boss_harvester_animations.json','boss_chamber':'boss_chamber_animations.json','boss_black':'boss_black_animations.json'}
summary={}
for kind,b in program['bosses'].items():
    actions={int(k) for k in b['actions']}; link_count=0; common_count=len(b.get('common_actions',[]))
    for fr,links in b['links'].items():
        if int(fr) not in actions: errors.append(f'{kind}: link from missing action {fr}')
        for link in links:
            link_count+=1
            if int(link['to']) not in actions: errors.append(f'{kind}: link to missing action {link["to"]}')
    for ca in b.get('common_actions',[]):
        for cmd in ca.get('commands',[]):
            if int(cmd.get('type',-1))==40:
                aid=int(cmd.get('actionExec',{}).get('actionId',-1))
                if aid not in actions: errors.append(f'{kind}: common actionExec target missing {aid}')
    adata=json.load(open(root/'data'/animfiles[kind],encoding='utf8'))
    for mid,aname in b.get('motion_animation_map',{}).items():
        if aname not in adata: errors.append(f'{kind}: motion {mid} -> missing animation {aname}')
        else:
            for fr in adata[aname].get('frames',[]):
                if not (root/fr['file']).exists(): errors.append(f'{kind}: missing frame {fr["file"]}')
    summary[kind]={'actions':len(actions),'links':link_count,'common_actions':common_count,'mapped_motions':len(b.get('motion_animation_map',{}))}
# Referenced source SE
for sid,path in program.get('se_paths',{}).items():
    if not (root/path).exists(): errors.append(f'missing source SE {sid}: {path}')
# Static res:// references in game script
g=(root/'scripts/game.gd').read_text(encoding='utf8')
for ref in sorted(set(re.findall(r'"res://([^"\n]+)"',g))):
    if not (root/ref).exists(): errors.append('game.gd missing res://'+ref)
# Stage graph connectivity
graph=collections.defaultdict(set)
for p in portals:
    a=p.get('areas',[])
    if len(a)!=2: continue
    x,y=a[0]['stage'],a[1]['stage']; graph[x].add(y); graph[y].add(x)
seen={'outside'}; q=['outside']
while q:
    x=q.pop(0)
    for y in graph[x]:
        if y not in seen: seen.add(y); q.append(y)
if set(manifest)!=seen: errors.append(f'stage reachability mismatch: reached {len(seen)}/{len(manifest)} missing={sorted(set(manifest)-seen)}')
# Entity baseline from V5
entity_count=sum(len(v) for v in entities.values())
if len(manifest)!=35: errors.append(f'expected 35 stages, got {len(manifest)}')
if len(portals)!=37: errors.append(f'expected 37 portals, got {len(portals)}')
if entity_count!=396: errors.append(f'expected 396 entities, got {entity_count}')
# Known source inconsistency: Harvester actions reference motion 13 but source Animation 31 has no motion 13.
for kind,r in motion_report.items():
    if r.get('failed'):
        warnings.append({kind:r['failed']})
result={'version':6,'summary':summary,'stages':len(manifest),'reachable_stages':len(seen),'portals':len(portals),'entities':entity_count,'source_se':len(program.get('se_paths',{})),'motion_warnings':warnings,'errors':errors}
json.dump(result,open(root/'data/v6_integrity_report.json','w',encoding='utf8'),ensure_ascii=False,indent=2)
print(json.dumps(result,ensure_ascii=False,indent=2))
if errors: sys.exit(1)
