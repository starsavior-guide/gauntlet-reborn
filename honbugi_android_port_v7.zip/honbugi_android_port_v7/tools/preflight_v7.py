#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys, hashlib
from pathlib import Path
from collections import deque

ROOT = Path(__file__).resolve().parents[1]
errors=[]; warnings=[]; checks={}

def err(msg): errors.append(msg)
def warn(msg): warnings.append(msg)

def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as e:
        err(f'JSON parse failed: {path.relative_to(ROOT)}: {e}')
        return None

# 1. JSON integrity
json_files=sorted(ROOT.rglob('*.json'))
for p in json_files: load_json(p)
checks['json_files_parsed']=len(json_files)

# 2. Core files and project settings
required=['project.godot','export_presets.cfg','scenes/main.tscn','scripts/game.gd','scripts/touch_ring.gd']
for rel in required:
    if not (ROOT/rel).is_file(): err(f'Missing core file: {rel}')
project=(ROOT/'project.godot').read_text(encoding='utf-8') if (ROOT/'project.godot').exists() else ''
export=(ROOT/'export_presets.cfg').read_text(encoding='utf-8') if (ROOT/'export_presets.cfg').exists() else ''
if 'config/name="ホンブギの冒険 Android Port V7"' not in project: err('Project name is not V7')
if 'run/main_scene="res://scenes/main.tscn"' not in project: err('Main scene setting is wrong')
if 'window/size/viewport_width=1280' not in project or 'window/size/viewport_height=800' not in project: err('Viewport must be 1280x800')
if 'window/handheld/orientation=0' not in project: err('Android orientation must be landscape (0)')
if 'renderer/rendering_method.mobile="gl_compatibility"' not in project: warn('Mobile renderer is not explicitly gl_compatibility')
if 'name="Android"' not in export or 'platform="Android"' not in export: err('Android export preset missing')
if 'export_path="build/HonbugiV7.apk"' not in export: err('Android export path is not build/HonbugiV7.apk')
if 'architectures/arm64-v8a=true' not in export: err('arm64-v8a must be enabled')

# 3. res:// references in text resources/scripts
text_paths=list(ROOT.rglob('*.gd'))+list(ROOT.rglob('*.tscn'))+[ROOT/'project.godot']
ref_re=re.compile(r'(?:load|preload)\(\s*["\']res://([^"\']+)["\']\s*\)|(?:path|script)\s*=\s*["\']res://([^"\']+)["\']')
refs=set()
for p in text_paths:
    if not p.exists(): continue
    text=p.read_text(encoding='utf-8')
    for m in ref_re.finditer(text):
        rel=m.group(1) or m.group(2)
        refs.add(rel)
        if not (ROOT/rel).exists(): err(f'Missing res:// reference from {p.relative_to(ROOT)}: {rel}')
checks['res_references_checked']=len(refs)

# 4. Asset paths stored in JSON (res:// strings)
json_refs=set()
def walk(v):
    if isinstance(v,dict):
        for x in v.values(): walk(x)
    elif isinstance(v,list):
        for x in v: walk(x)
    elif isinstance(v,str) and v.startswith('res://'):
        json_refs.add(v[6:])
for p in json_files:
    d=load_json(p)
    if d is not None: walk(d)
for rel in sorted(json_refs):
    if not (ROOT/rel).exists(): err(f'Missing JSON res:// asset: {rel}')
checks['json_res_references_checked']=len(json_refs)

# 5. World graph from V5 manifest/portals retained by V7
manifest=load_json(ROOT/'data/stage_manifest_v5.json') or {}
portals_root=load_json(ROOT/'data/portals_v5.json') or {}
portals=portals_root.get('portals',[]) if isinstance(portals_root,dict) else []
graph={str(k):set() for k in manifest}
for p in portals:
    areas=p.get('areas',[])
    if len(areas)==2:
        a,b=str(areas[0].get('stage')),str(areas[1].get('stage'))
        if a in graph and b in graph:
            graph[a].add(b); graph[b].add(a)
        else: err(f'Portal refers to unknown stage: {a} <-> {b}')
start='outside'
seen=set([start]) if start in graph else set(); q=deque(seen)
while q:
    cur=q.popleft()
    for nxt in graph[cur]:
        if nxt not in seen: seen.add(nxt); q.append(nxt)
checks['stages']=len(manifest); checks['reachable_stages']=len(seen); checks['portals']=len(portals)
if len(seen)!=len(manifest): err(f'World graph disconnected: {len(seen)}/{len(manifest)} reachable')

# 6. Entity count / boss interpreter integrity via V6 validator-compatible data
entities=load_json(ROOT/'data/entities_v5.json') or {}
entity_count=0
if isinstance(entities,dict):
    for v in entities.values():
        if isinstance(v,list): entity_count += len(v)
        elif isinstance(v,dict):
            arr=v.get('entities',[])
            if isinstance(arr,list): entity_count += len(arr)
checks['entity_count']=entity_count
program=load_json(ROOT/'data/pgmmv_boss_programs_v6.json') or {}
bosses=program.get('bosses',{}) if isinstance(program,dict) else {}
checks['boss_program_count']=len(bosses)
for name,b in bosses.items():
    actions=b.get('actions',{}) if isinstance(b,dict) else {}
    links=b.get('links',{}) if isinstance(b,dict) else {}
    if isinstance(links,dict):
        for src, link_list in links.items():
            if str(src) not in actions:
                err(f'{name}: link source action missing: {src}')
            for link in link_list if isinstance(link_list,list) else []:
                if not isinstance(link,dict):
                    err(f'{name}: invalid link record under action {src}')
                    continue
                dst=str(link.get('to',''))
                if dst and dst not in actions:
                    err(f'{name}: link destination action missing: {src} -> {dst}')
    else:
        err(f'{name}: links must be a dictionary')
checks['bosses']=sorted(bosses.keys())

# 7. Save version/migration contract
game=(ROOT/'scripts/game.gd').read_text(encoding='utf-8') if (ROOT/'scripts/game.gd').exists() else ''
for needle in ['user://honbugi_v7_save.json','user://honbugi_v6_save.json','"version":7','V6 저장 → V7 이관 완료']:
    if needle not in game: err(f'V7 save/migration marker missing: {needle}')

# 8. Basic GDScript text sanity (real parse is done by tools/build_android_v7.sh when Godot is available)
for p in ROOT.rglob('*.gd'):
    txt=p.read_text(encoding='utf-8')
    if '\t' in txt: warn(f'Tab indentation present: {p.relative_to(ROOT)}')
    if txt.count('(')!=txt.count(')'): warn(f'Parenthesis count differs: {p.relative_to(ROOT)}')
    if txt.count('[')!=txt.count(']'): warn(f'Bracket count differs: {p.relative_to(ROOT)}')
checks['gdscript_files']=len(list(ROOT.rglob('*.gd')))

# 9. Fingerprints for the two main source files
for rel in ['scripts/game.gd','data/pgmmv_boss_programs_v6.json']:
    p=ROOT/rel
    if p.exists(): checks[f'sha256:{rel}']=hashlib.sha256(p.read_bytes()).hexdigest()

report={'version':7,'checks':checks,'warnings':warnings,'errors':errors,'ok':not errors}
out=ROOT/'data/v7_preflight_report.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if not errors else 1)
