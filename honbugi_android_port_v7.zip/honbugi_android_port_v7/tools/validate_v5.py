import json, sys
from pathlib import Path
from collections import defaultdict, deque
ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
def load(rel):
    try:return json.load(open(ROOT/rel,encoding='utf8'))
    except Exception as e: errors.append(f'{rel}: {e}'); return {}
manifest=load('data/stage_manifest_v5.json')
portals=load('data/portals_v5.json').get('portals',[])
entities=load('data/entities_v5.json')
facts=load('data/source_facts_v5.json')
if len(manifest)!=35: errors.append(f'stage count {len(manifest)} != 35')
if len(portals)!=37: errors.append(f'portal count {len(portals)} != 37')
if sum(len(v) for v in entities.values())!=396: errors.append(f'entity count {sum(len(v) for v in entities.values())} != 396')
for k,v in manifest.items():
    for f in ['image','meta']:
        if not (ROOT/v[f]).exists(): errors.append(f'missing {k}:{f}:{v[f]}')
    if v.get('bgm') and not (ROOT/v['bgm']).exists(): errors.append(f'missing bgm {k}:{v["bgm"]}')
    meta=load(v['meta'])
    if int(meta.get('width',0))<=0 or int(meta.get('height',0))<=0: errors.append(f'bad stage dimensions {k}')
g=defaultdict(set)
for p in portals:
    a=p.get('areas',[])
    if len(a)!=2: errors.append(f'portal {p.get("id")} area count'); continue
    x,y=a[0]['stage'],a[1]['stage']
    if x not in manifest or y not in manifest: errors.append(f'portal stage missing {p.get("id")}')
    g[x].add(y);g[y].add(x)
seen={'outside'};q=deque(['outside'])
while q:
    x=q.popleft()
    for y in g[x]:
        if y not in seen:seen.add(y);q.append(y)
if len(seen)!=len(manifest): errors.append('disconnected stages: '+','.join(sorted(set(manifest)-seen)))
for fn in ['player_v3_animations.json','item_v3_animations.json','boss_crab_animations.json','boss_harvester_animations.json','boss_chamber_animations.json','boss_black_animations.json']:
    d=load('data/'+fn)
    for an,v in d.items():
        for fr in v.get('frames',[]):
            if not (ROOT/fr['file']).exists(): errors.append(f'missing frame {fn}:{an}:{fr["file"]}')
expect={'boss_crab':700,'boss_harvester':3600,'boss_chamber':1420,'boss_black':1200}
found={}
for rows in entities.values():
    for e in rows:
        if e.get('kind') in expect: found[e['kind']]=int(e.get('source_max_hp',0))
for k,hp in expect.items():
    if found.get(k)!=hp: errors.append(f'{k} HP {found.get(k)} != {hp}')
if facts.get('harvester',{}).get('reward',{}).get('action_id')!=11: errors.append('harvester reward not action11/body')
if facts.get('chamber',{}).get('reward',{}).get('action_id')!=19: errors.append('chamber reward not action19/hands')
s=(ROOT/'scripts/game.gd').read_text(encoding='utf8')
for token in ['stage_manifest_v5.json','portals_v5.json','entities_v5.json','boss_harvester','boss_chamber','boss_black','honbugi_v5_save.json']:
    if token not in s: errors.append('script missing '+token)
if '; if ' in s: errors.append('inline ; if syntax remains')
if '\\"' in s: errors.append('escaped quote artifact in gdscript')
for fn in ['_spawn_stage_entities','_create_special_boss','_damage_boss','_update_boss']:
    if s.count('func '+fn)!=1: errors.append(f'function count {fn} !=1')
report={'ok':not errors,'stages':len(manifest),'portals':len(portals),'reachable_from_outside':len(seen),'entities':sum(len(v) for v in entities.values()),'bosses':found,'errors':errors,'warnings':warnings}
json.dump(report,open(ROOT/'data/v5_integrity_report.json','w',encoding='utf8'),ensure_ascii=False,indent=2)
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
