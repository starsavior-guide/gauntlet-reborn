#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 tools/preflight_v7.py

if [[ -n "${GODOT_BIN:-}" ]]; then
  GODOT="$GODOT_BIN"
elif command -v godot4 >/dev/null 2>&1; then
  GODOT="$(command -v godot4)"
elif command -v godot >/dev/null 2>&1; then
  GODOT="$(command -v godot)"
else
  echo "ERROR: Godot 4 not found. Set GODOT_BIN=/path/to/godot." >&2
  exit 20
fi

echo "[V7] Godot: $($GODOT --version)"
mkdir -p build
# Opening the project headlessly forces import and parses project scripts/resources.
"$GODOT" --headless --verbose --path "$ROOT" --editor --quit
# Android debug export uses Godot's configured debug keystore.
"$GODOT" --headless --verbose --path "$ROOT" --export-debug "Android" "$ROOT/build/HonbugiV7.apk"

test -s "$ROOT/build/HonbugiV7.apk"
echo "[V7] APK created: $ROOT/build/HonbugiV7.apk"
sha256sum "$ROOT/build/HonbugiV7.apk" | tee "$ROOT/build/HonbugiV7.apk.sha256"
