# ホンブギの冒険 Android 포팅 V7

V7은 V6의 35개 씬/37개 양방향 포털/396개 배치 엔티티와 PGMMV 보스 액션 그래프 런타임을 유지하면서, **실제 Android APK 빌드 직전 단계**를 정리한 버전입니다.

## V7에서 수정한 핵심

- Android 화면 방향을 `window/handheld/orientation=0`으로 수정했습니다. Godot에서 `0`은 Landscape, `1`은 Portrait라 V6의 `1`은 이 1280×800 게임에 잘못된 값이었습니다.
- Android export 출력은 `build/HonbugiV7.apk`입니다.
- V7 세이브는 `user://honbugi_v7_save.json`을 사용합니다.
- V7 저장이 없고 `honbugi_v6_save.json`이 있으면 LOAD/F9 시 읽은 뒤 V7 저장으로 자동 이관합니다.
- `tools/preflight_v7.py`가 JSON, res:// 리소스, 1280×800/가로화면, Android preset, arm64, 월드 그래프, 세이브 마이그레이션을 검사합니다.
- `tools/build_android_v7.sh`는 Godot가 설치된 환경에서 **headless import/스크립트 파싱 → Android Debug APK export → SHA-256 생성**까지 한 번에 실행합니다.
- `.github/workflows/build-android-debug.yml`을 추가했습니다. GitHub 저장소에 프로젝트를 올리면 `barichello/godot-ci:4.7.2` 환경에서 Android Debug APK를 빌드하고 Actions Artifact로 올리도록 되어 있습니다.

## 로컬에서 APK 빌드

Godot 4.7.2와 Android export 환경이 준비된 컴퓨터에서 프로젝트 루트에서 실행합니다.

```bash
./tools/build_android_v7.sh
```

Godot 실행파일이 PATH에 없다면:

```bash
GODOT_BIN=/path/to/godot ./tools/build_android_v7.sh
```

성공 시:

```text
build/HonbugiV7.apk
build/HonbugiV7.apk.sha256
```

## GitHub Actions로 APK 빌드

이 폴더 전체를 GitHub 저장소 루트에 올린 뒤 `Actions > Build Android Debug APK > Run workflow`를 실행합니다. 성공하면 `HonbugiV7-Android-Debug` Artifact 안에 APK와 SHA-256 파일이 생성됩니다.

사용한 CI 이미지는 Android SDK/ADB/OpenJDK와 Godot export template을 포함하는 `barichello/godot-ci:4.7.2`입니다.

## 현재 보존된 게임 범위

- 실제 플레이 씬: 35
- 원본 양방향 포털: 37
- 배치 엔티티: 396
- PGMMV 보스 그래프: かに / ハーベスター / チャンバー / 黒にょん
- 원본 보스 액션/액션 링크/Common Action 데이터 및 V6 인터프리터 유지
- 모바일 터치 조작, 저장/로드, 장비·아이템·보스 진행 상태 유지

## 검증의 의미

`preflight_v7.py`는 정적 무결성 검사입니다. 실제 GDScript parser와 Android exporter 검증은 Godot 실행파일이 필요하기 때문에 `build_android_v7.sh`와 GitHub Actions 단계에서 수행하도록 분리했습니다.
